const keyboardShortcuts = [];

docsearch({
  container: "#searchbox",
  appId: "74VN1YECLR",
  indexName: "gpt-index",
  apiKey: "fb20bbeb2c3b7f63f89bacf797bf3a34",
});
