::: llama_index.core.output_parsers
    options:
      members:
        - PydanticOutputParser
