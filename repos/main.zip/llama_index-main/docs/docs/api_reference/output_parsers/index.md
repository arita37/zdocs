::: llama_index.core.types
    options:
      members:
        - BaseOutputParser
