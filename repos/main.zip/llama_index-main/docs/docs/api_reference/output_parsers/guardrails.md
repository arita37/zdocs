::: llama_index.output_parsers.guardrails
    options:
      members:
        - GuardrailsOutputParser
