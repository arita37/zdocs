::: llama_index.agent.coa
    options:
      members:
        - CoAAgentWorker
