::: llama_index.agent.introspective
    options:
      members:
        - IntrospectiveAgentWorker
        - SelfReflectionAgentWorker
        - ToolInteractiveReflectionAgentWorker
