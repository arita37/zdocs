::: llama_index.agent.openai_legacy
    options:
      members:
        - ContextRetrieverOpenAIAgent
        - FnRetrieverOpenAIAgent
