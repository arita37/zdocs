::: llama_index.agent.llm_compiler
    options:
      members:
        - LLMCompilerAgentWorker
