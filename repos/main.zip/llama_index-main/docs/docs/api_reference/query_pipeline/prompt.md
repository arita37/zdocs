::: llama_index.core.prompts.base.PromptComponent
