::: llama_index.core.objects.base.ObjectRetrieverComponent
