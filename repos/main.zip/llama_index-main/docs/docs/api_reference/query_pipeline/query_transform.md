::: llama_index.core.indices.query.query_transform.base.QueryTransformComponent
