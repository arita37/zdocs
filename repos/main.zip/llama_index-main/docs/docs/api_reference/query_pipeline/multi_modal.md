::: llama_index.core.multi_modal_llms.base.BaseMultiModalComponent
