::: llama_index.core.base.base_retriever.RetrieverComponent
