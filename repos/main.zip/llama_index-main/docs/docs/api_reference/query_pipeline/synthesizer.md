::: llama_index.core.response_synthesizers.base.SynthesizerComponent
