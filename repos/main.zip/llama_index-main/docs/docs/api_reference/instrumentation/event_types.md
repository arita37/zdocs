::: llama_index.core.instrumentation.events.base.BaseEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.agent.AgentChatWithStepEndEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.agent.AgentChatWithStepStartEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.agent.AgentRunStepEndEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.agent.AgentRunStepStartEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.agent.AgentToolCallEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.chat_engine.StreamChatDeltaReceivedEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.chat_engine.StreamChatEndEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.chat_engine.StreamChatErrorEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.chat_engine.StreamChatStartEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.embedding.EmbeddingEndEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.embedding.EmbeddingStartEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.llm.LLMChatEndEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.llm.LLMChatStartEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.llm.LLMCompletionEndEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.llm.LLMCompletionStartEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.llm.LLMPredictEndEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.llm.LLMPredictStartEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.query.QueryEndEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.query.QueryStartEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.retrieval.RetrievalEndEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.retrieval.RetrievalStartEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.synthesis.GetResponseEndEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.synthesis.GetResponseStartEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.synthesis.SynthesizeEndEvent
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.events.synthesis.SynthesizeStartEvent
    options:
      show_root_heading: true
      show_root_full_path: false
