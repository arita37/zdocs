::: llama_index.core.instrumentation.span.base.BaseSpan
    options:
      show_root_heading: true
      show_root_full_path: false
