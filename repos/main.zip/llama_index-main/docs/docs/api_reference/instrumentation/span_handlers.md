::: llama_index.core.instrumentation.span_handlers.base.BaseSpanHandler
    options:
      show_root_heading: true
      show_root_full_path: false

::: llama_index.core.instrumentation.span_handlers.simple.SimpleSpanHandler
    options:
      show_root_heading: true
      show_root_full_path: false
