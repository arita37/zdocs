::: llama_index.core.instrumentation.event_handlers.base.BaseEventHandler
    options:
      show_root_heading: true
      show_root_full_path: false
