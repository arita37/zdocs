::: llama_index.core.evaluation
    options:
      members:
        - BaseEvaluator
        - EvaluationResult
        - BatchEvalRunner
