::: llama_index.core.evaluation
    options:
      members:
        - BaseRetrievalEvaluator
        - RetrieverEvaluator
        - RetrievalEvalResult
