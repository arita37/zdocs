::: llama_index.evaluation.tonic_validate
    options:
      members:
        - AnswerConsistencyBinaryEvaluator
        - AnswerConsistencyEvaluator
        - AnswerSimilarityEvaluator
        - AugmentationAccuracyEvaluator
        - AugmentationPrecisionEvaluator
        - RetrievalPrecisionEvaluator
        - TonicValidateEvaluator
