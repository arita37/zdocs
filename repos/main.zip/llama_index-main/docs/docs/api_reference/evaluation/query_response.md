::: llama_index.core.evaluation
    options:
      members:
        - QueryResponseEvaluator
        - RelevancyEvaluator
