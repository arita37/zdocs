::: llama_index.core.evaluation
    options:
      members:
        - MRR
        - HitRate
        - RetrievalMetricResult
        - resolve_metrics
