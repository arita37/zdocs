::: llama_index.core.query_engine
    options:
      members:
        - SimpleMultiModalQueryEngine
