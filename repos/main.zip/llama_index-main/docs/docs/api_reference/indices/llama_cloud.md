::: llama_index.indices.managed.llama_cloud
    options:
      members:
        - LlamaCloudIndex
