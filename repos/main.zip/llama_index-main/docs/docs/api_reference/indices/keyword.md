::: llama_index.core.indices
    options:
      members:
        - KeywordTableIndex
        - SimpleKeywordTableIndex
        - RAKEKeywordTableIndex
