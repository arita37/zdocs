::: llama_index.core.indices
    options:
      show_root_heading: False
      members:
        - TreeIndex
