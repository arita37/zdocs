::: llama_index.core.indices
    options:
      members:
        - DocumentSummaryIndex
