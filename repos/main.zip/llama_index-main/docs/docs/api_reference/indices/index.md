::: llama_index.core.indices.base
    options:
      members:
        - BaseIndex
