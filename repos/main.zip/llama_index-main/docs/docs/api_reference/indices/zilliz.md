::: llama_index.indices.managed.zilliz
    options:
      members:
        - ZillizCloudPipelineIndex
