::: llama_index.indices.managed.colbert
    options:
      members:
        - ColbertIndex
