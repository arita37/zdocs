::: llama_index.indices.managed.google
    options:
      members:
        - GoogleIndex
