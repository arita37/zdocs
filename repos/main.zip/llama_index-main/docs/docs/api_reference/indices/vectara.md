::: llama_index.indices.managed.vectara
    options:
      members:
        - VectaraIndex
