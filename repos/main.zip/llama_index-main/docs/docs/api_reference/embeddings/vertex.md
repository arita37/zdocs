::: llama_index.embeddings.vertex
    options:
      members:
        - VertexMultiModalEmbedding
        - VertexTextEmbedding
