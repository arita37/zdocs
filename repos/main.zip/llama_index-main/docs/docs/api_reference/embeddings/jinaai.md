::: llama_index.embeddings.jinaai
    options:
      members:
        - JinaEmbedding
