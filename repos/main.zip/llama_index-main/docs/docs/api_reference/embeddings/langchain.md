::: llama_index.embeddings.langchain
    options:
      members:
        - LangchainEmbedding
