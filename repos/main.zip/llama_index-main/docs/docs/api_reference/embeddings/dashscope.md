::: llama_index.embeddings.dashscope
    options:
      members:
        - DashScopeEmbedding
