::: llama_index.embeddings.azure_openai
    options:
      members:
        - AzureOpenAIEmbedding
