::: llama_index.embeddings.llm_rails
    options:
      members:
        - LLMRailsEmbedding
