::: llama_index.embeddings.adapter
    options:
      members:
        - AdapterEmbeddingModel
        - LinearAdapterEmbeddingModel
