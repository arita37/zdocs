::: llama_index.embeddings.premai
    options:
      members:
        - PremAIEmbeddings
