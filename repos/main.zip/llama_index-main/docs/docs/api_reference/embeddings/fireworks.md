::: llama_index.embeddings.fireworks
    options:
      members:
        - FireworksEmbedding
