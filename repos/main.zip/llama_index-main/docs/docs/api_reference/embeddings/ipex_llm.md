::: llama_index.embeddings.ipex_llm
    options:
      members:
        - IpexLLMEmbedding
