::: llama_index.embeddings.elasticsearch
    options:
      members:
        - ElasticsearchEmbedding
