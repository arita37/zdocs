::: llama_index.embeddings.together
    options:
      members:
        - TogetherEmbedding
