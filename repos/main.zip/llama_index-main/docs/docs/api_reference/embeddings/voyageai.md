::: llama_index.embeddings.voyageai
    options:
      members:
        - VoyageEmbedding
