::: llama_index.embeddings.cloudflare_workersai
    options:
      members:
        - CloudflareEmbedding
