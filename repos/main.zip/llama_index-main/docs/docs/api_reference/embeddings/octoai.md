::: llama_index.embeddings.octoai
    options:
      members:
        - OctoAIEmbeddings
