::: llama_index.embeddings.deepinfra
    options:
      members:
        - DeepInfraEmbeddingModel
