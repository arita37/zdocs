::: llama_index.embeddings.huggingface_optimum
    options:
      members:
        - OptimumEmbedding
