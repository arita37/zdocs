::: llama_index.embeddings.mistralai
    options:
      members:
        - MistralAIEmbedding
