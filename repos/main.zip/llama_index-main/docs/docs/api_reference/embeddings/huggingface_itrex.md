::: llama_index.embeddings.huggingface_itrex
    options:
      members:
        - QuantizedBgeEmbedding
