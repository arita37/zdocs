::: llama_index.embeddings.anyscale
    options:
      members:
        - AnyscaleEmbedding
