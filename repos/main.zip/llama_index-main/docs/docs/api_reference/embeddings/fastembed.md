::: llama_index.embeddings.fastembed
    options:
      members:
        - FastEmbedEmbedding
