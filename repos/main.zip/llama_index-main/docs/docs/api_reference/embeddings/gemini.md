::: llama_index.embeddings.gemini
    options:
      members:
        - GeminiEmbedding
