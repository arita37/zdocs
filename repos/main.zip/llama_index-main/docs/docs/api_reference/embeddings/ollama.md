::: llama_index.embeddings.ollama
    options:
      members:
        - OllamaEmbedding
