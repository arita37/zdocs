::: llama_index.embeddings.alephalpha
    options:
      members:
        - AlephAlphaEmbedding
