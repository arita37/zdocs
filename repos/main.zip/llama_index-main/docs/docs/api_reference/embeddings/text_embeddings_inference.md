::: llama_index.embeddings.text_embeddings_inference
    options:
      members:
        - TextEmbeddingsInference
