::: llama_index.embeddings.google
    options:
      members:
        - GeminiEmbedding
        - GooglePaLMEmbedding
        - GoogleUnivSentEncoderEmbedding
