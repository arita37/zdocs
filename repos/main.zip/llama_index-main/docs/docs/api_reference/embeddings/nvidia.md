::: llama_index.embeddings.nvidia
    options:
      members:
        - NVIDIA
