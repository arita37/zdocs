::: llama_index.embeddings.bedrock
    options:
      members:
        - BedrockEmbedding
