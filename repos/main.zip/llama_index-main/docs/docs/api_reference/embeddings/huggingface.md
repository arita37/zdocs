::: llama_index.embeddings.huggingface
    options:
      members:
        - HuggingFaceEmbedding
        - HuggingFaceInferenceAPIEmbedding
