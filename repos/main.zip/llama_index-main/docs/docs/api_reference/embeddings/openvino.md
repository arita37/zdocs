::: llama_index.embeddings.huggingface_openvino
    options:
      members:
        - OpenVINOEmbedding
