::: llama_index.embeddings.llamafile
    options:
      members:
        - LlamafileEmbedding
