::: llama_index.embeddings.clarifai
    options:
      members:
        - ClarifaiEmbedding
