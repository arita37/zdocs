::: llama_index.core.embeddings
    options:
      members:
        - BaseEmbedding
        - resolve_embed_model
