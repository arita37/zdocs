::: llama_index.embeddings.cohere
    options:
      members:
        - CohereEmbedding
