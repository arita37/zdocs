::: llama_index.embeddings.openai
    options:
      members:
        - OpenAIEmbedding
