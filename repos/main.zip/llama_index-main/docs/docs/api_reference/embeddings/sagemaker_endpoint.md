::: llama_index.embeddings.sagemaker_endpoint
    options:
      members:
        - SageMakerEmbedding
