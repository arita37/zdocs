::: llama_index.embeddings.nomic
    options:
      members:
        - NomicEmbedding
