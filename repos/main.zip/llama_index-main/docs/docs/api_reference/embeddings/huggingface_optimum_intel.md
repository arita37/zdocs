::: llama_index.embeddings.huggingface_optimum_intel
    options:
      members:
        - IntelEmbedding
