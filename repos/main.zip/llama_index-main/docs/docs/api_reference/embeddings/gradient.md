::: llama_index.embeddings.gradient
    options:
      members:
        - GradientEmbedding
