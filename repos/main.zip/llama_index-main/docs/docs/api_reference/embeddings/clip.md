::: llama_index.embeddings.clip
    options:
      members:
        - ClipEmbedding
