::: llama_index.embeddings.instructor
    options:
      members:
        - InstructorEmbedding
