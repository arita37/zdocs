::: llama_index.postprocessor.colbert_rerank
    options:
      members:
        - ColbertRerank
