::: llama_index.core.postprocessor.types
    options:
      members:
        - BaseNodePostprocessor
