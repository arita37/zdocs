::: llama_index.postprocessor.openvino_rerank
    options:
      members:
        - OpenVINORerank
