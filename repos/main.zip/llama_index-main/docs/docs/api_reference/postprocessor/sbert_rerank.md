::: llama_index.postprocessor.sbert_rerank
    options:
      members:
        - SentenceTransformerRerank
