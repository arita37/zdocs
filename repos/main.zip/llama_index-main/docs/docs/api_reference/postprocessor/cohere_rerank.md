::: llama_index.postprocessor.cohere_rerank
    options:
      members:
        - CohereRerank
