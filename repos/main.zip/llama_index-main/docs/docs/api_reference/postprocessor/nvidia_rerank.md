::: llama_index.postprocessor.nvidia_rerank
    options:
      members:
        - NVIDIA
