::: llama_index.postprocessor.jinaai_rerank
    options:
      members:
        - JinaRerank
