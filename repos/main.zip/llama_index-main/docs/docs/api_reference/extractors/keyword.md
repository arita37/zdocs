::: llama_index.core.extractors
    options:
      members:
        - KeywordExtractor
