::: llama_index.core.extractors.interface
    options:
      members:
        - BaseExtractor
