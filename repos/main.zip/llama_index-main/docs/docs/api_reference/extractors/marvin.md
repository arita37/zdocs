::: llama_index.extractors.marvin
    options:
      members:
        - MarvinMetadataExtractor
