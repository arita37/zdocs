::: llama_index.extractors.entity
    options:
      members:
        - EntityExtractor
