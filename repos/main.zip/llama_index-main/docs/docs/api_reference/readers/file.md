::: llama_index.readers.file
    options:
      members:
        - CSVReader
        - DocxReader
        - EpubReader
        - FlatReader
        - HTMLTagReader
        - HWPReader
        - IPYNBReader
        - ImageCaptionReader
        - ImageReader
        - ImageTabularChartReader
        - ImageVisionLLMReader
        - MarkdownReader
        - MboxReader
        - PDFReader
        - PagedCSVReader
        - PandasCSVReader
        - PptxReader
        - PyMuPDFReader
        - RTFReader
        - UnstructuredReader
        - VideoAudioReader
        - XMLReader
