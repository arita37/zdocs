::: llama_index.readers.nougat_ocr
    options:
      members:
        - PDFNougatOCR
