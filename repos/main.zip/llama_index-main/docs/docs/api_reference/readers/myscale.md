::: llama_index.readers.myscale
    options:
      members:
        - MyScaleReader
