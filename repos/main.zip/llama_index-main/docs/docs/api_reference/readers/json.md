::: llama_index.readers.json
    options:
      members:
        - JSONReader
