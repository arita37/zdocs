::: llama_index.readers.assemblyai
    options:
      members:
        - AssemblyAIAudioTranscriptReader
