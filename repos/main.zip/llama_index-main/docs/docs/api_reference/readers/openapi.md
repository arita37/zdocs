::: llama_index.readers.openapi
    options:
      members:
        - OpenAPIReader
