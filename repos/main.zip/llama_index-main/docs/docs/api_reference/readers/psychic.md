::: llama_index.readers.psychic
    options:
      members:
        - PsychicReader
