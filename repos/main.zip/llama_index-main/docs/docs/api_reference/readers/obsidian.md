::: llama_index.readers.obsidian
    options:
      members:
        - ObsidianReader
