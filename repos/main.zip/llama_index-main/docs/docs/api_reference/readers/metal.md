::: llama_index.readers.metal
    options:
      members:
        - MetalReader
