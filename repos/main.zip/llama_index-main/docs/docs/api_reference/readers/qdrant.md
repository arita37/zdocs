::: llama_index.readers.qdrant
    options:
      members:
        - QdrantReader
