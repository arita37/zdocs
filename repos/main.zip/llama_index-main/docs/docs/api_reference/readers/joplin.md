::: llama_index.readers.joplin
    options:
      members:
        - JoplinReader
