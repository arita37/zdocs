::: llama_index.readers.airbyte_shopify
    options:
      members:
        - AirbyteShopifyReader
