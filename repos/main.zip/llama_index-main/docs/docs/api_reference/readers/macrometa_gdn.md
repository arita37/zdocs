::: llama_index.readers.macrometa_gdn
    options:
      members:
        - MacrometaGDNReader
