::: llama_index.core.readers.base
    options:
      members:
        - BaseReader
        - BasePydanticReader
