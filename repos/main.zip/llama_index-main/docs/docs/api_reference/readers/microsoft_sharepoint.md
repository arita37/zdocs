::: llama_index.readers.microsoft_sharepoint
    options:
      members:
        - SharePointReader
