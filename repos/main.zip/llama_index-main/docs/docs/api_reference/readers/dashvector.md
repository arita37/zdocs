::: llama_index.readers.dashvector
    options:
      members:
        - DashVectorReader
