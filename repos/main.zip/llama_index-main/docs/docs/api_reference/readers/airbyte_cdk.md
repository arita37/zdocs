::: llama_index.readers.airbyte_cdk
    options:
      members:
        - AirbyteCDKReader
