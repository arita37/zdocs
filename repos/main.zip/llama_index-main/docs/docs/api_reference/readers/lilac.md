::: llama_index.readers.lilac
    options:
      members:
        - LilacReader
