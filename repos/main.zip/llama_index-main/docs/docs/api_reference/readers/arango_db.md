::: llama_index.readers.arango_db
    options:
      members:
        - SimpleArangoDBReader
