::: llama_index.readers.docugami
    options:
      members:
        - DocugamiReader
