::: llama_index.readers.dad_jokes
    options:
      members:
        - DadJokesReader
