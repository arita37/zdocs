::: llama_index.readers.couchbase
    options:
      members:
        - CouchbaseReader
