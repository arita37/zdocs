::: llama_index.readers.airbyte_stripe
    options:
      members:
        - AirbyteStripeReader
