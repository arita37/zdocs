::: llama_index.readers.mangoapps_guides
    options:
      members:
        - MangoppsGuidesReader
