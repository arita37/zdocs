::: llama_index.readers.firebase_realtimedb
    options:
      members:
        - FirebaseRealtimeDatabaseReader
