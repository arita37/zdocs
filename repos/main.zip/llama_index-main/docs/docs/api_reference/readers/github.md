::: llama_index.readers.github
    options:
      members:
        - GitHubRepositoryCollaboratorsReader
        - GitHubRepositoryIssuesReader
        - GithubRepositoryReader
