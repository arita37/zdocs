::: llama_index.readers.minio
    options:
      members:
        - BotoMinioReader
        - MinioReader
