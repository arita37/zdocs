::: llama_index.readers.couchdb
    options:
      members:
        - SimpleCouchDBReader
