::: llama_index.readers.kibela
    options:
      members:
        - KibelaReader
