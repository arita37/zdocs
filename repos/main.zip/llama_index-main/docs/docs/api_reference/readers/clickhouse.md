::: llama_index.readers.clickhouse
    options:
      members:
        - ClickHouseReader
