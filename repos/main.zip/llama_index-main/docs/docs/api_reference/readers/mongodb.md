::: llama_index.readers.mongodb
    options:
      members:
        - SimpleMongoReader
