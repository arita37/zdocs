::: llama_index.readers.patentsview
    options:
      members:
        - PatentsviewReader
