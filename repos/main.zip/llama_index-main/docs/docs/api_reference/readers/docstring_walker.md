::: llama_index.readers.docstring_walker
    options:
      members:
        - DocstringWalker
