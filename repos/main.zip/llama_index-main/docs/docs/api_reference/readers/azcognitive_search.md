::: llama_index.readers.azcognitive_search
    options:
      members:
        - AzCognitiveSearchReader
