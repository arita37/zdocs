::: llama_index.readers.azstorage_blob
    options:
      members:
        - AzStorageBlobReader
