::: llama_index.readers.chatgpt_plugin
    options:
      members:
        - ChatGPTRetrievalPluginReader
