::: llama_index.readers.graphql
    options:
      members:
        - GraphQLReader
