::: llama_index.callbacks.uptrain
    options:
      members:
        - UpTrainCallbackHandler
