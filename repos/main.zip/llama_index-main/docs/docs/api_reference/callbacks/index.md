# Core Callback Classes

::: llama_index.core.callbacks.base
    options:
      members:
        - CallbackManager

::: llama_index.core.callbacks.base_handler
    options:
      members:
        - BaseCallbackHandler

::: llama_index.core.callbacks.schema
    options:
      members:
        - CBEvent
        - CBEventType
        - EventPayload
