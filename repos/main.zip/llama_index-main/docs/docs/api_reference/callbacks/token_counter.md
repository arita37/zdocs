::: llama_index.core.callbacks.token_counting
    options:
      members:
        - TokenCountingHandler
