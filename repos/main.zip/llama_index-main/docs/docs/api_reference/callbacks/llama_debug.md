::: llama_index.core.callbacks.llama_debug
    options:
      members:
        - LlamaDebugHandler
