::: llama_index.callbacks.wandb
    options:
      members:
        - WandbCallbackHandler
