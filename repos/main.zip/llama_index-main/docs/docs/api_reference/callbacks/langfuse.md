::: llama_index.callbacks.langfuse
    options:
      members:
        - langfuse_callback_handler
