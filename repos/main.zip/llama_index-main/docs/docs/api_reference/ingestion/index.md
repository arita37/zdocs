::: llama_index.core.ingestion.pipeline
    options:
      members:
        - IngestionPipeline
        - DocstoreStrategy
