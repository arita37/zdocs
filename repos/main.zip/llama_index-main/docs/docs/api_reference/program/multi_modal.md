::: llama_index.core.program.multi_modal_llm_program
    options:
      members:
        - MultiModalLLMCompletionProgram
