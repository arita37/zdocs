::: llama_index.core.program.llm_program
    options:
      members:
        - LLMTextCompletionProgram
