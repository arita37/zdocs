::: llama_index.program.openai
    options:
      members:
        - OpenAIPydanticProgram
