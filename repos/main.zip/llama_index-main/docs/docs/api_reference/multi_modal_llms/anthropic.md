::: llama_index.multi_modal_llms.anthropic
    options:
      members:
        - AnthropicMultiModal
