::: llama_index.multi_modal_llms.ollama
    options:
      members:
        - OllamaMultiModal
