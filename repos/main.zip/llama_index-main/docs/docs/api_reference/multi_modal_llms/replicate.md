::: llama_index.multi_modal_llms.replicate
    options:
      members:
        - ReplicateMultiModal
