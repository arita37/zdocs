::: llama_index.multi_modal_llms.gemini
    options:
      members:
        - GeminiMultiModal
