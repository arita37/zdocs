::: llama_index.multi_modal_llms.dashscope
    options:
      members:
        - DashScopeMultiModal
