::: llama_index.multi_modal_llms.azure_openai
    options:
      members:
        - AzureOpenAIMultiModal
