::: llama_index.multi_modal_llms.openai
    options:
      members:
        - OpenAIMultiModal
