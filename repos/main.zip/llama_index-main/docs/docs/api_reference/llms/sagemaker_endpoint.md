::: llama_index.llms.sagemaker_endpoint
    options:
      members:
        - SageMakerLLM
