::: llama_index.llms.perplexity
    options:
      members:
        - Perplexity
