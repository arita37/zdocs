::: llama_index.llms.groq
    options:
      members:
        - Groq
