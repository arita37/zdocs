::: llama_index.llms.mistral_rs
    options:
      members:
        - MistralRs
