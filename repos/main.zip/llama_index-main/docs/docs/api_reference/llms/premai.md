::: llama_index.llms.premai
    options:
      members:
        - PremAI
