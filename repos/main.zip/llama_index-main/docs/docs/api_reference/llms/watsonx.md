::: llama_index.llms.watsonx
    options:
      members:
        - WatsonX
