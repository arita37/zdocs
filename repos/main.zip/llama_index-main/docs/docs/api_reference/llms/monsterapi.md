::: llama_index.llms.monsterapi
    options:
      members:
        - MonsterLLM
