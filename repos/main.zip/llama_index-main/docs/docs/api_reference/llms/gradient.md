::: llama_index.llms.gradient
    options:
      members:
        - GradientBaseModelLLM
        - GradientModelAdapterLLM
