::: llama_index.llms.openllm
    options:
      members:
        - OpenLLM
        - OpenLLMAPI
