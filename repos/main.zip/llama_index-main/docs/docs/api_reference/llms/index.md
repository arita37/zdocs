::: llama_index.core.llms.llm
    options:
      members:
        - LLM
      show_source: false
      inherited_members: true
