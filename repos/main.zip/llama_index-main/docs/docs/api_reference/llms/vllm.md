::: llama_index.llms.vllm
    options:
      members:
        - Vllm
        - VllmServer
