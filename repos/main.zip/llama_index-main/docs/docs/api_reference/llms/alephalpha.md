::: llama_index.llms.alephalpha
    options:
      members:
        - AlephAlpha
