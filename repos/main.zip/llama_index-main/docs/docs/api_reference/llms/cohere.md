::: llama_index.llms.cohere
    options:
      members:
        - Cohere
