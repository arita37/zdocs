::: llama_index.llms.litellm
    options:
      members:
        - LiteLLM
