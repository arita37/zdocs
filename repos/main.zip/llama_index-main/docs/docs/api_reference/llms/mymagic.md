::: llama_index.llms.mymagic
    options:
      members:
        - MyMagicAI
