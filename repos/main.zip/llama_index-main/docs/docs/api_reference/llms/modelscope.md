::: llama_index.llms.modelscope
    options:
      members:
        - ModelScopeLLM
