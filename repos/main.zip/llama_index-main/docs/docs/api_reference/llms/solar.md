::: llama_index.llms.solar
    options:
      members:
        - Solar
