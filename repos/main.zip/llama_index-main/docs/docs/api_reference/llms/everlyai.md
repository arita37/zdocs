::: llama_index.llms.everlyai
    options:
      members:
        - EverlyAI
