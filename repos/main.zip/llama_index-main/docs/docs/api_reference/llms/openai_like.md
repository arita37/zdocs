::: llama_index.llms.openai_like
    options:
      members:
        - OpenAILike
