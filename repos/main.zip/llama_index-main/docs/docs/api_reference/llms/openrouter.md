::: llama_index.llms.openrouter
    options:
      members:
        - OpenRouter
