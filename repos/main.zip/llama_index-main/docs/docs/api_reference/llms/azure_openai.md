::: llama_index.llms.azure_openai
    options:
      members:
        - AsyncAzureOpenAI
        - AzureOpenAI
        - SyncAzureOpenAI
