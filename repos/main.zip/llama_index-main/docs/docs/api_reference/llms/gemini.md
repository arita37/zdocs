::: llama_index.llms.gemini
    options:
      members:
        - Gemini
