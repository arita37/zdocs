::: llama_index.llms.llamafile
    options:
      members:
        - Llamafile
