::: llama_index.llms.openvino
    options:
      members:
        - OpenVINOLLM
