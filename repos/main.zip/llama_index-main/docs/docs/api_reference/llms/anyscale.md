::: llama_index.llms.anyscale
    options:
      members:
        - Anyscale
