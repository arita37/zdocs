::: llama_index.llms.nvidia
    options:
      members:
        - NVIDIA
