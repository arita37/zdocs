::: llama_index.llms.llama_cpp
    options:
      members:
        - LlamaCPP
