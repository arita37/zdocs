::: llama_index.llms.predibase
    options:
      members:
        - PredibaseLLM
