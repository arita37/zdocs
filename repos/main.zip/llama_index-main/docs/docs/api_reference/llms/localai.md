::: llama_index.llms.localai
    options:
      members:
        - LocalAI
