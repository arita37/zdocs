::: llama_index.llms.octoai
    options:
      members:
        - OctoAI
