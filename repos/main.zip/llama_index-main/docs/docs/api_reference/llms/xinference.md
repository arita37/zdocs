::: llama_index.llms.xinference
    options:
      members:
        - Xinference
