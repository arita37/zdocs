::: llama_index.llms.fireworks
    options:
      members:
        - Fireworks
