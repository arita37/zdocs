::: llama_index.llms.friendli
    options:
      members:
        - Friendli
