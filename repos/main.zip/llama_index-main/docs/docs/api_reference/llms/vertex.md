::: llama_index.llms.vertex
    options:
      members:
        - Vertex
