::: llama_index.llms.nvidia_tensorrt
    options:
      members:
        - LocalTensorRTLLM
