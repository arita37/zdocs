::: llama_index.llms.llama_api
    options:
      members:
        - LlamaAPI
