::: llama_index.llms.mistralai
    options:
      members:
        - MistralAI
