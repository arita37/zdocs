::: llama_index.llms.nvidia_triton
    options:
      members:
        - NvidiaTriton
