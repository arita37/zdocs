::: llama_index.llms.ipex_llm
    options:
      members:
        - IpexLLM
