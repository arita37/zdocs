::: llama_index.core.objects
