::: llama_index.packs.redis_ingestion_pipeline
    options:
      members:
        - RedisIngestionPipelinePack
