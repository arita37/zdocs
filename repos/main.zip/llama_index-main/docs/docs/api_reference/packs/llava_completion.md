::: llama_index.packs.llava_completion
    options:
      members:
        - LlavaCompletionPack
