::: llama_index.packs.rag_cli_local
    options:
      members:
        - LocalRAGCLIPack
