::: llama_index.packs.self_discover
    options:
      members:
        - SelfDiscoverPack
