::: llama_index.packs.cogniswitch_agent
    options:
      members:
        - CogniswitchAgentPack
