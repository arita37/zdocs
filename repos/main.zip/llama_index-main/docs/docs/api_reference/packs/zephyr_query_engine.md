::: llama_index.packs.zephyr_query_engine
    options:
      members:
        - ZephyrQueryEnginePack
