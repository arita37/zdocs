::: llama_index.packs.cohere_citation_chat
    options:
      members:
        - CohereCitationChatEnginePack
