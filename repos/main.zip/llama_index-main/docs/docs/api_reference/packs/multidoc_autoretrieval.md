::: llama_index.packs.multidoc_autoretrieval
    options:
      members:
        - MultiDocAutoRetrieverPack
