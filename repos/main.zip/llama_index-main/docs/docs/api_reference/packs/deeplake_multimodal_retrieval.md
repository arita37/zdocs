::: llama_index.packs.deeplake_multimodal_retrieval
    options:
      members:
        - DeepLakeMultimodalRetrieverPack
