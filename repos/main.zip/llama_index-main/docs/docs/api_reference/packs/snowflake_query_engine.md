::: llama_index.packs.snowflake_query_engine
    options:
      members:
        - SnowflakeQueryEnginePack
