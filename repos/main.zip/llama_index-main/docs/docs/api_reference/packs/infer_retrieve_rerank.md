::: llama_index.packs.infer_retrieve_rerank
    options:
      members:
        - InferRetrieveRerankPack
