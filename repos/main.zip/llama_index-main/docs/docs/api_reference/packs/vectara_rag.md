::: llama_index.packs.vectara_rag
    options:
      members:
        - VectaraRagPack
