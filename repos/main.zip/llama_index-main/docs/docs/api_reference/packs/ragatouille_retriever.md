::: llama_index.packs.ragatouille_retriever
    options:
      members:
        - RAGatouilleRetrieverPack
