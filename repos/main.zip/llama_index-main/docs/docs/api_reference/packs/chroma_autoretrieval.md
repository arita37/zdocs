::: llama_index.packs.chroma_autoretrieval
    options:
      members:
        - ChromaAutoretrievalPack
