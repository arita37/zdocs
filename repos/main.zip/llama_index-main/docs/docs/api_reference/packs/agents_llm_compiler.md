::: llama_index.packs.agents_llm_compiler
    options:
      members:
        - LLMCompilerAgentPack
