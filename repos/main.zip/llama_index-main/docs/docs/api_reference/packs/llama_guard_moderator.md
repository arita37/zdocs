::: llama_index.packs.llama_guard_moderator
    options:
      members:
        - LlamaGuardModeratorPack
