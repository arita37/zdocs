::: llama_index.packs.deeplake_deepmemory_retriever
    options:
      members:
        - DeepMemoryRetrieverPack
