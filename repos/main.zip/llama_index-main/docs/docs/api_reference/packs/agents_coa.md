::: llama_index.packs.agents_coa
    options:
      members:
        - CoAAgentPack
        - CoAAgentWorker
