::: llama_index.packs.rag_fusion_query_pipeline
    options:
      members:
        - RAGFusionPipelinePack
