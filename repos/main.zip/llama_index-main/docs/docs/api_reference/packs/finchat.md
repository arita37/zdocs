::: llama_index.packs.finchat
    options:
      members:
        - FinanceChatPack
