::: llama_index.packs.stock_market_data_query_engine
    options:
      members:
        - StockMarketDataQueryEnginePack
