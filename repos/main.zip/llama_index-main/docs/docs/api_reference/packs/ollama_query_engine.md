::: llama_index.packs.ollama_query_engine
    options:
      members:
        - OllamaQueryEnginePack
