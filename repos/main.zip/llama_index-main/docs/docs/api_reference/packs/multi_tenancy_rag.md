::: llama_index.packs.multi_tenancy_rag
    options:
      members:
        - MultiTenancyRAGPack
