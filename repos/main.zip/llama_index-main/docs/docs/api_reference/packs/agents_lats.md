::: llama_index.packs.agents_lats
    options:
      members:
        - LATSPack
