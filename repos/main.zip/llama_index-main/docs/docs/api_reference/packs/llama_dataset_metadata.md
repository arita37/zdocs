::: llama_index.packs.llama_dataset_metadata
    options:
      members:
        - LlamaDatasetMetadataPack
