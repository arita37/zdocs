::: llama_index.packs.dense_x_retrieval
    options:
      members:
        - DenseXRetrievalPack
