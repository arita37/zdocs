::: llama_index.packs.multi_document_agents
    options:
      members:
        - MultiDocumentAgentsPack
