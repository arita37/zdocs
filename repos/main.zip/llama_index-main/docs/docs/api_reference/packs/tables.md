::: llama_index.packs.tables
    options:
      members:
        - ChainOfTablePack
        - MixSelfConsistencyPack
