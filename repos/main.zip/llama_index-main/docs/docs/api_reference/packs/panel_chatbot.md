::: llama_index.packs.panel_chatbot
    options:
      members:
        - PanelChatPack
