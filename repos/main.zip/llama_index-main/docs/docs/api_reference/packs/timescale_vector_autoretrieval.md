::: llama_index.packs.timescale_vector_autoretrieval
    options:
      members:
        - TimescaleVectorAutoretrievalPack
