::: llama_index.packs.self_rag
    options:
      members:
        - SelfRAGPack
