::: llama_index.packs.auto_merging_retriever
    options:
      members:
        - AutoMergingRetrieverPack
